
App.config = {};

(function(){
	
	App.config = {
		name: 'TitanTricks'
	}
	
})();
