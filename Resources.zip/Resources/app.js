/**
 * TitanTricks app 
 * @version      0.2
 * @author       Javier Rayon, 2011. Criteria Studio.
 */

Ti.include('/app/tools.js', '/app/TitanTricks.js');

(function(){
	
	var win = App.ui.createAppWindow();
	
	win.open();
})();
 
